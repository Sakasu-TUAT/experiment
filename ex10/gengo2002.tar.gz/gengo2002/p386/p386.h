#if !defined _P386_H_
#define _P386_H_

void p386_reset(void);
int p386_step(void);
int p386_run(void);

#endif /* _P386_H_ */
