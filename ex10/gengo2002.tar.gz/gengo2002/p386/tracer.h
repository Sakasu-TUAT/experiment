#if !defined _TRACER_H_
#define _TRACER_H_

void tracer(void);

#endif /* _TRACER_H_ */
