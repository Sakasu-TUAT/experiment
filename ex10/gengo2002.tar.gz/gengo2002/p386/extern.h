/*
$B%0%m!<%P%kJQ?t$X$N%"%/%;%9$N$?$a$N%X%C%@(B
*/

#if !defined _EXTERN_H_
#define _EXTERN_H_

#define __P386_GLOBAL__ extern
#include "global.c"
#undef __P386_GLOBAL__

#endif /* _EXTERN_H_ */
