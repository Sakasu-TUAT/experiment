#if !defined _LABELGEN_H_
#define _LABELGEN_H_

int getnewnum(void);

#endif /* _LABELGEN_H_ */
