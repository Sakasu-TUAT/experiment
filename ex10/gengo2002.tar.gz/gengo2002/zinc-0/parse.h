#if !defined _PARSE_H_
#define _PARSE_H_

void init_parse(void);
void parse(void);

#endif /* _PARSE_H_ */
